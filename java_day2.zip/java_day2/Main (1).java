/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) 
	{
	   // System.out.println("Hello World");
		
		Scanner sc = new Scanner(System.in);
	          	
		// input for subjects marks
		System.out.println("Enter marks for five subjects");
         int s1=sc.nextInt();
         int s2=sc.nextInt();
         int s3=sc.nextInt();
         int s4=sc.nextInt();
         int s5=sc.nextInt();
		
		double ans = s1+s2+s3+s4+s5;
		System.out.println(ans);
		double perc=(ans/500)*100;
		System.out.println(perc);
		
		if(perc>=70)
		{
		    System.out.println("A grade");
		}
		else if(perc>=60 && perc<70)
		{
		    System.out.println("Grade B");
		}
		else if(perc>=45 && perc<60)
		{
		    System.out.println("grade C");
		}
		else
		{
		    System.out.println("Fail");
		}
		
	
	}
}
