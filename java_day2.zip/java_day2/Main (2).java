/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;

class input
{
    String name;
    int date,month,year;
    int salary,age;
    double tax,sal;
    Scanner sc = new Scanner(System.in);
     input()
    {
       System.out.println("Enter Name Of Employee");
       name=sc.nextLine();
       System.out.println("Date of Birth then Month And then Year ");
       date=sc.nextInt();
       month=sc.nextInt();
       year=sc.nextInt();
       System.out.println("Enter salary");
       salary=sc.nextInt();
    }
      
    void display()
    {
        age=2020-year;
        sal=salary*12;
        System.out.println("Name is "+name);
        System.out.println("Age is "+age);
        System.out.println("Annual salary is "+sal);
        tax=tax(sal);
        System.out.println("Tax is is "+tax);
        
    }
    
    double tax(double sal)
    {
        double ans;
        if(sal>=500000)
        {
            ans=sal*0.2;
        }
        else if(sal>=400000)
        {
            ans=sal*0.15;
        }
        else if(sal>300000)
        {
            ans=sal*0.1;
        }
        else if(sal>200000)
        {
            ans=sal*0.05;
        }
        else{
            ans=0;
        }
    return ans;
    }

}
public class Main
{
	public static void main(String[] args) 
	{
	   // System.out.println("Hello World");
      
       input t=new input();
       //t.input();
       t.display();
       }
}
