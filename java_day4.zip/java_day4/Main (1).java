/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main1
{
	public static void main(String[] args) {
		
		
		int[] arr=new int[5];
		 Scanner sc=new Scanner(System.in);
		System.out.println("Enter Five numbers");
		 for(int i=0;i<5;i++)
		 {
		     arr[i]=sc.nextInt();
		 }
		 System.out.println("odd number are :");
		 for(int i=0;i<5;i++)
		 {
		     
		     if(arr[i]%2!=0)
		     {
		       System.out.println(arr[i]);
		     }
		     
		 }
		 
	
/*
o/p
Enter Five numbers                                                                                                              
11                                                                                                                              
12                                                                                                                              
13                                                                                                                              
14                                                                                                                              
15                                                                                                                              
odd number are :                                                                                                                
11                                                                                                                              
13                                                                                                                              
15                                                                                                                              
           
*/


