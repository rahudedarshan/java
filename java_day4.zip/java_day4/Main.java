/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
class Avenger
{
    int age;
    String power,weapon,planet,name;
    Scanner sc=new Scanner(System.in);
    void GetDetails()
    {
      System.out.println("Enter the name");
      name=sc.nextLine();
      System.out.println("Enter the Age");
      age=sc.nextInt();
      System.out.println("Enter the power");
      power=sc.next();
      System.out.println("Enter the weapon");
      weapon=sc.next();
      System.out.println("Enter the planet");
      planet=sc.next();
 
    }
    
    void DisplayDetails()
    {
        System.out.println("Name is "+name);
        System.out.println("Age is "+age);
        System.out.println("Power of Avenger is "+ power);
        System.out.println("Weapon is "+weapon);
        System.out.println("planet is "+planet);
    }
}
public class Main
{
	public static void main(String[] args) 
	{
	    
    //		System.out.println("Hello World");
	
	    Avenger[] Avengers=new Avenger[5];
	    for(int i=0;i<5;i++)
	    {
	        Avengers[i]=new Avenger();
	        Avengers[i].GetDetails();
	         System.out.println("");
	        Avengers[i].DisplayDetails();
	        System.out.println("");
	    }
	}
}
