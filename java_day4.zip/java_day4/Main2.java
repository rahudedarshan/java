/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.Scanner;
public class Main2
{
	public static void main(String[] args) {
		
		int sum=0;
		int[] arr=new int[5];
		 Scanner sc=new Scanner(System.in);
		System.out.println("Enter Five numbers");
		 for(int i=0;i<5;i++)
		 {
		     arr[i]=sc.nextInt();
		 }
		 
		 for(int i=0;i<5;i++)
		 {
		     
		    sum=sum+arr[i];
		 }
		 
		 System.out.println("Sum is "+sum);
		 
 }

}

/*
o/p :
Enter Five numbers                                                                                                              
10                                                                                                                              
10                                                                                                                              
10                                                                                                                              
10                                                                                                                              
10                                                                                                                              
Sum is 50                                                                                                                       
 */                                                                                                                                */      

